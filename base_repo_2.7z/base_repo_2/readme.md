git add .
git commit -m 'init commit'
clear
git switch -c feature
git add .
git commit -m "add feature"
git commit -am "edit feature"
git commit -am 'Add feature doc'
