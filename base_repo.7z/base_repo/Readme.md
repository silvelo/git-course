Id CommandLine

---

1 mkdir base_repo
2 cd .\base_repo\
 3 clear
4 git init
5 code .
6 git add .
7 git commit -m 'init commit'
8 clear
9 git switch -c feature
10 git add .
11 git commit -m "add feature"
12 git commit -am "edit feature"
13 git switch master
14 clear
15 git commit -am 'Fix bug'
16 git add .
17 git commit -m 'Add doc'
18 git commit -am 'Edit bug'
19 clear
20 git switch -c feature-2
21 clear
22 git add .
23 git commit -m 'Add feature 2'
24 git commit -am 'Edit feature 2'
25 clear
26 git logs
27 git log
28 clear
29 git switch master
30 git commit -ma 'Fix new bug'
31 git commit -am 'Fix new bug'
32 clear
33 explorer .
